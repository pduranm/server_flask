from engine.calc_jornadas import *

if __name__ == "__main__":

    while True:

        input_date = input("\nIntroduce la fecha de inicio en este formato '01/01/2000' o 'exit' para salir: ")

        if input_date.lower() == 'exit':
            print("Saliendo de la aplicacion")
            break
        try:
            Calculadora.calcular(input_date)
        except Exception as e: 
            print(f"Hubo un error al procesar la fecha {e}")


# https://www.calendarios-laborales.es/autocompletar.php?ano_usar=2023&term=Jerez
# https://www.calendarios-laborales.es/calendario-laboral-jerez_de_los_caballeros-2023-ba






