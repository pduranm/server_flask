from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from config.paramenters import MES_REFERENCIA, DIA_REFERENCIA


def es_fecha(valor: Any) -> bool:
    if isinstance(valor, datetime):
        return True
    elif isinstance(valor, str):
        try:
            datetime.strptime(valor, "%Y-%m-%d")
            return True
        except ValueError:
            return False
    else:
        return False


def es_anterior_a_1_julio(fecha: Any) -> bool:
    if es_fecha(fecha):
        fecha_objeto: datetime = fecha
    else:
        fecha_objeto: datetime = datetime.strptime(fecha, "%d/%m/%Y")
    return (fecha_objeto.month, fecha_objeto.day) < (MES_REFERENCIA, DIA_REFERENCIA)


def contar_dias_entre_fechas(mes_inicio: int, dia_inicio: int, mes_fin: int, dia_fin: int, futuro: bool = False) -> int:
    fecha_inicio: datetime = datetime.strptime(f"{mes_inicio}/{dia_inicio}/{datetime.now().year}", "%m/%d/%Y")
    fecha_fin: datetime = datetime.strptime(f"{mes_fin}/{dia_fin}/{datetime.now().year+1 if futuro else datetime.now().year}", "%m/%d/%Y")
    diferencia: timedelta  = fecha_fin - fecha_inicio
    diferencia_limitada: timedelta = min(diferencia, timedelta(days=365))
    return diferencia_limitada.days


def mapear_mes_a_numero(mes: str) -> Optional[int]:
    meses: Dict[str,int] = {
        'Enero': 1,
        'Febrero': 2,
        'Marzo': 3,
        'Abril': 4,
        'Mayo': 5,
        'Junio': 6,
        'Julio': 7,
        'Agosto': 8,
        'Septiembre': 9,
        'Octubre': 10,
        'Noviembre': 11,
        'Diciembre': 12
    }
    return meses.get(mes, None)


def cargar_calendario_desde_archivo(ruta_archivo: str) -> Dict[Any, Any]:
    calendario: Dict[Any, Any] = {}

    with open(ruta_archivo, 'r', encoding='utf-8') as archivo:
        mes_actual: Optional[int] = None
        for linea in archivo:
            linea: str = linea.strip()
            if linea:
                if linea.isalpha():
                    # mes_actual = linea
                    mes_actual: Optional[int] = mapear_mes_a_numero(linea)
                    calendario[mes_actual] = {}
                else:
                    dia, evento = linea.split('-', 1)
                    calendario[mes_actual][int(dia)] = evento.strip()
                    
    return calendario


def contar_dias_festivos_acumulados(calendario: Dict[Any,Any], mes: int, dia: int) -> int:
    total_dias_festivos: int = 0

    fecha_referencia: datetime = datetime.strptime(f"{mes}/{dia}/{datetime.now().year}", "%m/%d/%Y")

    for key in calendario.keys():
        if key >= fecha_referencia.month:
            for dia_v in calendario[key].keys():
                fecha_eval: datetime = datetime.strptime(f"{key}/{dia_v}/{datetime.now().year}", "%m/%d/%Y")
                # if fecha_eval.weekday() != 5:
                if fecha_eval >= fecha_referencia:
                    total_dias_festivos += 1

    return total_dias_festivos


def contar_dias_festivos_acumulados_anyo_n1(calendario: Dict[Any,Any]) -> int:
    total_dias_festivos: int = 0

    for key in calendario.keys():
        for _ in calendario[key].keys():
            total_dias_festivos += 1

    return total_dias_festivos


def dias_hasta_final_de_anyo(input_date: datetime) -> int:
    final_de_ano: datetime = datetime(input_date.year, 12, 31)
    diferencia: timedelta = final_de_ano - input_date
    return diferencia.days


def dias_sabados_domingos_hasta_final_de_ano(input_date: datetime) -> int:
    final_de_ano: datetime = datetime(input_date.year, 12, 31)
    dias_fin_de_semana: int = 0
    while input_date <= final_de_ano:
        if input_date.weekday() == 5 or input_date.weekday() == 6:
            dias_fin_de_semana += 1
        input_date += timedelta(days=1)

    return dias_fin_de_semana


def dias_en_proximo_anio(year_actual: int) -> int:
    proximo_anio: int = year_actual + 1
    primer_dia_proximo_anio: datetime.date = datetime(proximo_anio, 1, 1).date()   
    ultimo_dia_proximo_anio: datetime.date = datetime(proximo_anio, 12, 31).date()
    diferencia_en_dias = (ultimo_dia_proximo_anio - primer_dia_proximo_anio).days + 1
    
    return diferencia_en_dias





