from cx_Freeze import setup, Executable

# SETUP CX FREEZE
setup(
    name="Calculadora de jornadas",
    version="1.0",
    description="da el numero de jornadas que trabajar al año",
    author="iaycd",
    executables=[Executable("main.py")],
    include_files=[
        ('config/calendario_laboral_jerez_2023.txt', 'config/calendario_laboral_jerez_2023.txt'),
        ('config/calendario_laboral_jerez_2024.txt', 'config/calendario_laboral_jerez_2024.txt'),
    ],
)