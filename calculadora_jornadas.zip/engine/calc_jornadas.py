from datetime import datetime
from config.paramenters import *
from utils.utils import *


class Calculadora(object):
    __calendario_jerez23 = cargar_calendario_desde_archivo(RUTA_CALENDARIO_2023)
    __calendario_jerez24 = cargar_calendario_desde_archivo(RUTA_CALENDARIO_2024)

    @staticmethod
    def calcular(input_date: str) -> None:
        fecha = datetime.strptime(input_date, "%d/%m/%Y")

        dias_pendientes_anyo_n: int = dias_hasta_final_de_anyo(fecha)
        dias_pendientes_anyo_n1: int = dias_en_proximo_anio(fecha.year)

        dias_weekend_anyo_n: int = dias_sabados_domingos_hasta_final_de_ano(fecha)
        dias_weekend_anyo_n1: int = dias_sabados_domingos_hasta_final_de_ano(datetime.strptime(f"01/01/{fecha.year+1}", "%d/%m/%Y"))

        acumu_total = contar_dias_festivos_acumulados(Calculadora.__calendario_jerez23, fecha.month, fecha.day)
        acumu_total_n1 = contar_dias_festivos_acumulados_anyo_n1(Calculadora.__calendario_jerez24)

        check_01_07 = es_anterior_a_1_julio(fecha)

        cont_dias = contar_dias_entre_fechas(fecha.month, fecha.day, MES_REFERENCIA, DIA_REFERENCIA)
        devengo_vacaciones = round(30*cont_dias/dias_en_proximo_anio(fecha.year-1)) if check_01_07 else 0

        cont_dias_n1 = contar_dias_entre_fechas(fecha.month, fecha.day, MES_REFERENCIA, DIA_REFERENCIA, futuro=True)
        devengo_vacaciones_n1 = 30 if check_01_07 else round(30*cont_dias_n1/dias_en_proximo_anio(fecha.year))

        resultado :int = dias_pendientes_anyo_n-dias_weekend_anyo_n-acumu_total-devengo_vacaciones
        resutaldo_n1: int = dias_pendientes_anyo_n1-dias_weekend_anyo_n1-acumu_total_n1-devengo_vacaciones_n1
        resultado = {
            "dias_pendientes_anyo_n": dias_pendientes_anyo_n,
            "dias_weekend_anyo_n": dias_weekend_anyo_n,
            "acumu_total": acumu_total,
            "devengo_vacaciones": devengo_vacaciones,
            "resultado": resultado,
            "dias_pendientes_anyo_n1": dias_pendientes_anyo_n1,
            "dias_weekend_anyo_n1": dias_weekend_anyo_n1,
            "acumu_total_n1": acumu_total_n1,
            "devengo_vacaciones_n1": devengo_vacaciones_n1,
            "resutaldo_n1": 221 if check_01_07 else resutaldo_n1 + INDICE_CORRECTOR
        }

        return resultado

