# RUTA_CALENDARIO_2023 = './lib/config/calendario_laboral_jerez_2023.txt'
# RUTA_CALENDARIO_2024 = './lib/config/calendario_laboral_jerez_2024.txt'
RUTA_CALENDARIO_2023 = './config/calendario_laboral_jerez_2023.txt'
RUTA_CALENDARIO_2024 = './config/calendario_laboral_jerez_2024.txt'
MES_REFERENCIA: int = 7
DIA_REFERENCIA: int = 1
INDICE_CORRECTOR = 3
