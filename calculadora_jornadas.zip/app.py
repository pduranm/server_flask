from flask import Flask, render_template, request, jsonify
from engine.calc_jornadas import *

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        input_date = request.json.get('input_date')
        try:
            resultado = Calculadora.calcular(input_date)
            return jsonify({'resultado': resultado, 'error_msg': None})
        except Exception as e:
            return jsonify({'resultado': None, 'error_msg': str(e)}), 500

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)




# 1. PROBAR CON UVICORN 
# 2. HACER QUE LA RESPUESTA QUE DA POR CONSOLA AL HACER EL PRINT: te la dé por el frontend